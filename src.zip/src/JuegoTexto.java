
import GUI.CapturaNombres;
import GUI.CivitasView;
import GUI.Dado;
import civitas.CivitasJuego;
import controladorCivitas.Controlador;
import java.util.ArrayList;
import GUI.Vista;


/**
 *
 * @author 
 */
public class JuegoTexto {
    
    public static void main(String[] args) {
        
        CivitasView vista = new CivitasView();
        Dado.createInstance(vista);
        
        
        CapturaNombres captura_nombres = new CapturaNombres(vista, true);
        ArrayList<String> jugadores = new ArrayList();
        jugadores = captura_nombres.getNombres();
        
        CivitasJuego juego = new CivitasJuego(jugadores, false);
        Controlador controlador = new Controlador(juego, vista);
        controlador.juega();
        
    }

}