package civitas;

/**
 *
 * @author mjcs
 */
public enum OperacionJuego {
    PASAR_TURNO,
    AVANZAR,
    COMPRAR,
    GESTIONAR;
}
