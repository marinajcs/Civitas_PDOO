package controladorCivitas;

import GUI.CivitasView;
import civitas.CivitasJuego;
import civitas.GestionInmobiliaria;
import civitas.OperacionInmobiliaria;
import civitas.OperacionJuego;

/**
 *
 * @author mjcs
 */
public class Controlador {
    //private VistaTextual vista;
    private CivitasView vista;
    private CivitasJuego juegoModel;
    
    public Controlador(CivitasJuego juego, CivitasView vista){
        this.vista = vista;
        this.juegoModel = juego;
        vista.setCivitasJuego(juegoModel);
    }
    
    public void juega(){
        boolean fin = false;
        while (!fin){
            vista.actualiza();
            vista.pausa();
            OperacionJuego sig = juegoModel.siguientePaso();
            vista.mostrarSiguienteOperacion(sig);
            
            if (sig != OperacionJuego.PASAR_TURNO)
                vista.mostrarEventos();
            
            fin = juegoModel.finalDelJuego();
            if (!fin){
                if (sig == OperacionJuego.COMPRAR){
                    Respuesta resp = vista.comprar();
                
                    if (resp == Respuesta.SÍ){
                        juegoModel.comprar();
                        vista.mostrarEventos();
                    }
         
                    juegoModel.siguientePasoCompletado(sig);
                    
                }else if (sig == OperacionJuego.GESTIONAR){
                    OperacionInmobiliaria opIn = vista.elegirOperacion();
                    int id = -1;
                    if (opIn != OperacionInmobiliaria.TERMINAR){
                        id = vista.elegirPropiedad();
                        if (id == 0)
                            opIn = OperacionInmobiliaria.TERMINAR;
                            
                        GestionInmobiliaria gestion = new GestionInmobiliaria(opIn, id);
                    
                        if (gestion.getOperacion() == OperacionInmobiliaria.TERMINAR)
                            vista.getCivitasJuego().siguientePasoCompletado(sig);
                        else if (gestion.getOperacion() == OperacionInmobiliaria.CONSTRUIR_CASA)
                            juegoModel.construirCasa(id);
                        else if (gestion.getOperacion() == OperacionInmobiliaria.CONSTRUIR_HOTEL)
                            juegoModel.construirHotel(id);
                    }else
                        juegoModel.siguientePasoCompletado(sig);
                }
            }
        }
        vista.actualiza();
    }
    
}
