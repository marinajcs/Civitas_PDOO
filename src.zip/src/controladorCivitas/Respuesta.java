package controladorCivitas;

public enum Respuesta {
    NO,
    SÍ
}
